﻿Bộ test bài tập lớn số 2. Lập trình hướng đối tượng. 2010.

Nội dung :
==========
17 test, liệt kê trong run-test.bat 
công thức chạy tự động 1 test: 
        type <shoot> | java <GAME> <map> <log>
trong đó,
<GAME>: tên class chính của chương trình
<map>: bản đồ máy bay, trong bộ test là các file *.map
<shoot>: file chứa trình tự các phát đạn cho 1 ván chơi 
        trong bộ test là các file *.shoot
<log>: tên file nhật trình, trong bộ test là các file log.*

Cách sử dụng
=============
*Test 01 chương trình: 
Chú ý: mã nguồn chương trình phải đặt trong thư mục khác, không được đặt trong thư mục chứa các file dữ liệu test. Giả sử đường dẫn đến thư mục chứa file README này là C:\asg02_test, mã nguồn chương trình cần test đặt tại thư mục C:\Dir1\subdir2\asg02. Thực hiện các bước sau:
1. Sửa lệnh gán test_path trong run-test.bat thành
set test_path=C:\asg02_test
2. Sửa lệnh gán test_place trong run-test.bat thành 
set test_place=C:\Dir1\subdir2
3. Chạy C:\asg02_test\run-test.bat asg02 <tên class chính>
Chú ý asg02 là tên thư mục chứa mã nguồn.

nội dung file mark là số test cho kết quả đúng. 
Ví dụ dòng sau có nghĩa có 8 test cho kết quả đúng, nếu không bỏ lỗi dấu cách thì đúng 10 test.
---------- A: 8
---------- A.W: 10

*Test nhiều chương trình (giống hệt asg01):
Thực hiện lần lượt các bước sau:
1- Thư mục bài nộp:
Tất cả bài nộp đặt trong 1 thư mục, giả sử C:\all , bài nộp của mỗi sinh viên nằm trong 1 thư mục có tên là username của sv. Ví dụ bài nộp của annv_54 đặt trong c:\all\annv_54. Các file .java phải đặt ngay tại c:\all\annv_54, không được để trong thư mục con nào khác.
2- Test script:
Sửa và dịch Asg01Test.cpp
3- Tạo danh sách bài nộp (xem định dạng tại Asg01Test.cpp)
4- Chạy test script (xem hướng dẫn tại Asg01Test.cpp), output là 1 file chứa kết quả của tất cả các bài nộp, có thể dán vào excel.

Một số lưu ý: 
1. bài không dịch được sẽ không có dòng nào trong file kết quả.
2. sv không qua test nào có thể là do file danh sách bài nộp sai tên class chính
3. sv chỉ qua 2 test (với bộ test kèm theo) có thể do lỗi Scanner input = new Scanner mỗi khi nhập phát bắn mới. Những bài này thường test bằng tay thì chạy bình thường.
4. một số bài nộp gây exception vô tận, nên Ctrl^C 01 lần để ngắt test đó (các test sau vẫn chạy tiếp)
5. có thể sự cố của 01 bài nộp làm dừng cả script, cần kiểm tra file kết quả cuối cùng.
