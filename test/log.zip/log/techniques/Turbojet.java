package techniques;

import models.Point;

public interface Turbojet {
	public void setTurbojet(Point[] dataTubojet);
	public Point[] getTurbojet();
}
