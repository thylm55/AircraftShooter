package techniques;

import models.Point;

public interface Engine {
	public void setEngine(Point[] data);
	public Point[] getEngine();
}
